rootProject.name = "microservice-parent"

include("product-service")